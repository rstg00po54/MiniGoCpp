#!/usr/bin/env bash
# Compile a standalone Android ARM64 benchmark, push over ADB and pin Neuron MDLA.
# Does not touch MiniGoCpp, GoEngine-java, Android app, or GitHub.
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE="${1:-all}"
DEVICE="${2:-mtk-mdla}"
WARMUP="${WARMUP:-100}"
RUNS="${RUNS:-1000}"
ADB="${ADB:-adb}"
case "$PROFILE" in tiny|stem|residual|all) ;; *) echo "Usage: bash run.sh [all|tiny|stem|residual] [mtk-mdla|mtk-dsp]" >&2; exit 2;; esac
case "$DEVICE" in mtk-mdla|mtk-dsp) ;; *) echo "Invalid Neuron device: $DEVICE" >&2; exit 2;; esac
command -v "$ADB" >/dev/null || { echo "ERROR: adb is unavailable" >&2; exit 1; }
NDK_DIR="${NDK:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
if [[ -z "$NDK_DIR" ]]; then
    for sdk in "${ANDROID_HOME:-$HOME/Android/Sdk}" "${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}"; do
        if [[ -d "$sdk/ndk/27.2.12479018" ]]; then NDK_DIR="$sdk/ndk/27.2.12479018"; break; fi
    done
fi
CXX="${CXX:-$NDK_DIR/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android29-clang++}"
[[ -x "$CXX" ]] || { echo "ERROR: Android NDK C++ compiler not found: $CXX" >&2; exit 1; }

# Prefer the phone's Wi-Fi ADB endpoint if the same phone is also attached by USB.
if [[ -z "${ADB_SERIAL:-}" ]]; then
    mapfile -t SERIALS < <("$ADB" devices | awk 'NR>1 && $2=="device" {print $1}')
    [[ ${#SERIALS[@]} -gt 0 ]] || { echo "ERROR: no authorized ADB devices" >&2; exit 1; }
    ADB_SERIAL=""
    for serial in "${SERIALS[@]}"; do
        if [[ "$serial" == *:* ]] && [[ "$("$ADB" -s "$serial" shell getprop ro.product.brand | tr -d '\r')" == "vivo" ]]; then
            ADB_SERIAL="$serial"; break
        fi
    done
    if [[ -z "$ADB_SERIAL" ]]; then
        for serial in "${SERIALS[@]}"; do
            if [[ "$("$ADB" -s "$serial" shell getprop ro.product.brand | tr -d '\r')" == "vivo" ]]; then
                ADB_SERIAL="$serial"; break
            fi
        done
    fi
    if [[ -z "$ADB_SERIAL" && ${#SERIALS[@]} -eq 1 ]]; then ADB_SERIAL="${SERIALS[0]}"; fi
    [[ -n "$ADB_SERIAL" ]] || { echo "ERROR: multiple devices; specify ADB_SERIAL=<device>" >&2; exit 1; }
fi
ARGS=("$ADB" -s "$ADB_SERIAL")
MODEL="$("${ARGS[@]}" shell getprop ro.product.model | tr -d '\r')"
SOC="$("${ARGS[@]}" shell getprop ro.soc.model | tr -d '\r')"
mkdir -p "$HERE/build" "$HERE/results"
BIN="$HERE/build/mtk_npu_bench"
if [[ ! -x "$BIN" || "$HERE/neuron_bench.cpp" -nt "$BIN" ]]; then
    echo 'Compiling native ARM64 benchmark...'
    "$CXX" -std=c++17 -O2 -fPIE -pie "$HERE/neuron_bench.cpp" -ldl -o "$BIN"
fi
REMOTE='/data/local/tmp/mtk_npu_bench'
"${ARGS[@]}" shell "mkdir -p '$REMOTE'"
"${ARGS[@]}" push "$BIN" "$REMOTE/mtk_npu_bench" >/dev/null
CPP="$NDK_DIR/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so"
[[ -s "$CPP" ]] && "${ARGS[@]}" push "$CPP" "$REMOTE/libc++_shared.so" >/dev/null
"${ARGS[@]}" shell "chmod 755 '$REMOTE/mtk_npu_bench'"
STAMP="$(date +%Y%m%d_%H%M%S)"
LOG="$HERE/results/${STAMP}_${PROFILE}_${DEVICE}.log"
echo "ADB_SERIAL=$ADB_SERIAL MODEL=$MODEL SOC=$SOC DEVICE=$DEVICE PROFILE=$PROFILE RUNS=$RUNS WARMUP=$WARMUP"
echo "Result log: $LOG"
CMD="cd '$REMOTE' && LD_LIBRARY_PATH='$REMOTE:/system_ext/lib64' ./mtk_npu_bench '$PROFILE' '$DEVICE' '$WARMUP' '$RUNS'"
if command -v timeout >/dev/null; then
    timeout "${NEURON_TIMEOUT:-600}" "${ARGS[@]}" shell "$CMD" | tee "$LOG"
else
    "${ARGS[@]}" shell "$CMD" | tee "$LOG"
fi
