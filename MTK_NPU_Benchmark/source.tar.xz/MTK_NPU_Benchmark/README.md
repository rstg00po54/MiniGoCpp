# MTK NPU Benchmark (Android ARM64, standalone)

A native MediaTek Neuron Adapter benchmark for the **physical NPU device** (`mtk-mdla`).
It has **no dependency** on MiniGoCpp, GoEngine-java, KataGo models, Python, or a GUI.
It does not alter any project source. Build and run from Ubuntu with Android NDK and ADB.

## Quick start

```bash
unzip MTK_NPU_Benchmark.zip
cd MTK_NPU_Benchmark
bash run.sh all mtk-mdla
```

You can choose profiles:

```bash
bash run.sh tiny mtk-mdla      # 9×9, 16->16, 3×3 valid
bash run.sh stem mtk-mdla      # 19×19, 22->128, 5×5 same
bash run.sh residual mtk-mdla  # 19×19, 128->128, 3×3 same
```

For the phone in your test logs, the script prefers Wi-Fi ADB if USB and Wi-Fi are both connected. Otherwise set the device explicitly:

```bash
ADB_SERIAL=192.168.0.184:5555 RUNS=1000 WARMUP=100 bash run.sh all mtk-mdla
```

Adjust NDK path if necessary: `NDK=/home/cc/Android/Sdk/ndk/27.2.12479018`.
The script uses the standard `aarch64-linux-android29-clang++` toolchain. An Android ARM64 binary is built once under `build/`, uploaded to `/data/local/tmp/mtk_npu_bench/`, and run via ADB. Its output is stored under `results/`.

## How to interpret results

The executable looks up `mtk-mdla` by exact name and calls `NeuronModel_getSupportedOperationsForDevices` and `NeuronCompilation_createForDevices`. There is **no silent CPU/DSP fallback**. The three FP16 tests use synthetic inputs and fixed, positive weights with an analytic reference so each result is validated.

- `NPU_BENCH_PASS`: successful numerical verification plus latency of the named standalone `CONV_2D` operation.
- `mean_ms`, `p50_ms`, `p95_ms`: elapsed execution time (including Neuron dispatch overhead).
- `calls_per_sec`: operation calls/s, **not** KataGo NN eval/s.
- `gmac_per_sec`: computed MAC throughput of this specific synthetic convolution shape. Different profiles are not comparable as a universal NPU TOPS rating.
- `compile_ms`: one-time graph compilation; excluded from inference latency.

This is not a *whole KataGo neural network* benchmark. For your previous full 10b model result, the existing independent command-line program in MiniGoCpp reported **700.16 NN eval/s** on the vivo X300 Pro (1000 timed calls); that is a separate network-specific metric.

### Tested vs untested

The program is source-level validated locally (`g++ -fsyntax-only`, `bash -n`), but no Android phone or NDK is connected to this ChatGPT runtime, so device execution has **not** been verified for this new package. A previous test of these same shapes on your `mtk-mdla` makes them reasonable choices, but their current timing cannot be predicted.
