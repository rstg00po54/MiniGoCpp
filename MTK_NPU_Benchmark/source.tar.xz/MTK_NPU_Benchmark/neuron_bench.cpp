// Independent MediaTek Neuron Adapter FP16 NPU benchmark for Android arm64.
// Runs synthetic convolution profiles on exactly the selected Neuron device.
// No KataGo or app integration; no fallback to CPU/DSP when mtk-mdla is chosen.
#include <dlfcn.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

struct NeuronModel;
struct NeuronCompilation;
struct NeuronExecution;
struct NeuronDevice;
struct NeuronOperandType {
    int32_t type;
    uint32_t dimensionCount;
    const uint32_t* dimensions;
    float scale;
    int32_t zeroPoint;
};

static constexpr int32_t TENSOR_FP16 = 8, INT32_SCALAR = 1, OP_CONV_2D = 3;

template <typename T> T api(void* lib, const char* symbol) {
    void* p = dlsym(lib, symbol);
    if (!p) throw std::runtime_error(std::string("Missing Neuron symbol: ") + symbol);
    return reinterpret_cast<T>(p);
}
static void check(int rc, const char* where) {
    if (rc != 0) throw std::runtime_error(std::string(where) + " rc=" + std::to_string(rc));
}
static double percentile(const std::vector<double>& v, double frac) {
    double f = (v.size() - 1) * frac;
    size_t a = size_t(f), b = std::min(a + 1, v.size() - 1);
    return v[a] + (v[b] - v[a]) * (f - double(a));
}
struct Profile {
    const char* name;
    uint32_t h, w, inputChannels, outputChannels, kernel, pad;
};
static constexpr Profile PROFILES[] = {
    {"tiny_conv",      9,  9,  16,  16, 3, 0},
    {"katago_stem",   19, 19,  22, 128, 5, 2},
    {"katago_resconv",19, 19, 128, 128, 3, 1},
};

class NeuronApi {
public:
    explicit NeuronApi(void* library):lib(library) {
        deviceCount = api<int (*)(uint32_t*)>(lib, "Neuron_getDeviceCount");
        getDevice = api<int (*)(uint32_t, NeuronDevice**)>(lib, "Neuron_getDevice");
        deviceName = api<int (*)(const NeuronDevice*, const char**)>(lib, "NeuronDevice_getName");
        modelCreate = api<int (*)(NeuronModel**)>(lib, "NeuronModel_create");
        modelFree = api<void (*)(NeuronModel*)>(lib, "NeuronModel_free");
        modelOperand = api<int (*)(NeuronModel*, const NeuronOperandType*)>(lib, "NeuronModel_addOperand");
        modelValue = api<int (*)(NeuronModel*, int32_t, const void*, size_t)>(lib, "NeuronModel_setOperandValue");
        modelOperation = api<int (*)(NeuronModel*, int32_t, uint32_t, const uint32_t*, uint32_t, const uint32_t*)>(lib, "NeuronModel_addOperation");
        modelIO = api<int (*)(NeuronModel*, uint32_t, const uint32_t*, uint32_t, const uint32_t*)>(lib, "NeuronModel_identifyInputsAndOutputs");
        modelFinish = api<int (*)(NeuronModel*)>(lib, "NeuronModel_finish");
        modelSupported = api<int (*)(const NeuronModel*, const NeuronDevice* const*, uint32_t, bool*)>(lib, "NeuronModel_getSupportedOperationsForDevices");
        compilationCreate = api<int (*)(NeuronModel*, const NeuronDevice* const*, uint32_t, NeuronCompilation**)>(lib, "NeuronCompilation_createForDevices");
        compilationFinish = api<int (*)(NeuronCompilation*)>(lib, "NeuronCompilation_finish");
        compilationFree = api<void (*)(NeuronCompilation*)>(lib, "NeuronCompilation_free");
        executionCreate = api<int (*)(NeuronCompilation*, NeuronExecution**)>(lib, "NeuronExecution_create");
        executionSetInput = api<int (*)(NeuronExecution*, int32_t, const NeuronOperandType*, const void*, size_t)>(lib, "NeuronExecution_setInput");
        executionSetOutput = api<int (*)(NeuronExecution*, int32_t, const NeuronOperandType*, void*, size_t)>(lib, "NeuronExecution_setOutput");
        executionCompute = api<int (*)(NeuronExecution*)>(lib, "NeuronExecution_compute");
        executionFree = api<void (*)(NeuronExecution*)>(lib, "NeuronExecution_free");
    }
    NeuronDevice* select(const std::string& requested) {
        uint32_t count = 0;
        check(deviceCount(&count), "Neuron_getDeviceCount");
        if (count > 64) throw std::runtime_error("Invalid Neuron device count");
        NeuronDevice* selected = nullptr;
        for (uint32_t i = 0; i < count; i++) {
            NeuronDevice* candidate = nullptr;
            const char* name = nullptr;
            check(getDevice(i, &candidate), "Neuron_getDevice");
            check(deviceName(candidate, &name), "NeuronDevice_getName");
            std::printf("NPU_DEVICE index=%u name=%s\n", i, name ? name : "unknown");
            if (name && requested == name) selected = candidate;
        }
        if (!selected) throw std::runtime_error("Requested Neuron device unavailable: " + requested);
        return selected;
    }
    int (*deviceCount)(uint32_t*);
    int (*getDevice)(uint32_t, NeuronDevice**);
    int (*deviceName)(const NeuronDevice*, const char**);
    int (*modelCreate)(NeuronModel**);
    void (*modelFree)(NeuronModel*);
    int (*modelOperand)(NeuronModel*, const NeuronOperandType*);
    int (*modelValue)(NeuronModel*, int32_t, const void*, size_t);
    int (*modelOperation)(NeuronModel*, int32_t, uint32_t, const uint32_t*, uint32_t, const uint32_t*);
    int (*modelIO)(NeuronModel*, uint32_t, const uint32_t*, uint32_t, const uint32_t*);
    int (*modelFinish)(NeuronModel*);
    int (*modelSupported)(const NeuronModel*, const NeuronDevice* const*, uint32_t, bool*);
    int (*compilationCreate)(NeuronModel*, const NeuronDevice* const*, uint32_t, NeuronCompilation**);
    int (*compilationFinish)(NeuronCompilation*);
    void (*compilationFree)(NeuronCompilation*);
    int (*executionCreate)(NeuronCompilation*, NeuronExecution**);
    int (*executionSetInput)(NeuronExecution*, int32_t, const NeuronOperandType*, const void*, size_t);
    int (*executionSetOutput)(NeuronExecution*, int32_t, const NeuronOperandType*, void*, size_t);
    int (*executionCompute)(NeuronExecution*);
    void (*executionFree)(NeuronExecution*);
private:
    void* lib;
};

static bool runProfile(NeuronApi& a, NeuronDevice* device, const std::string& target,
                       const Profile& p, int warmup, int runs) {
    const uint32_t oh = p.h + 2 * p.pad - p.kernel + 1;
    const uint32_t ow = p.w + 2 * p.pad - p.kernel + 1;
    const uint32_t inputDims[4] = {1, p.h, p.w, p.inputChannels};
    const uint32_t filterDims[4] = {p.outputChannels, p.kernel, p.kernel, p.inputChannels};
    const uint32_t biasDims[1] = {p.outputChannels};
    const uint32_t outputDims[4] = {1, oh, ow, p.outputChannels};
    const NeuronOperandType inputType = {TENSOR_FP16, 4, inputDims, 0.0f, 0};
    const NeuronOperandType filterType = {TENSOR_FP16, 4, filterDims, 0.0f, 0};
    const NeuronOperandType biasType = {TENSOR_FP16, 1, biasDims, 0.0f, 0};
    const NeuronOperandType scalarType = {INT32_SCALAR, 0, nullptr, 0.0f, 0};
    const NeuronOperandType outputType = {TENSOR_FP16, 4, outputDims, 0.0f, 0};
    const _Float16 kernelWeight = static_cast<_Float16>(1.0f / float(p.kernel * p.kernel * p.inputChannels));
    std::vector<_Float16> input(p.h * p.w * p.inputChannels, static_cast<_Float16>(1.0f));
    std::vector<_Float16> filter(p.outputChannels * p.kernel * p.kernel * p.inputChannels, kernelWeight);
    std::vector<_Float16> bias(p.outputChannels, static_cast<_Float16>(0.0f));
    std::vector<_Float16> output(oh * ow * p.outputChannels, static_cast<_Float16>(0.0f));
    NeuronModel* model = nullptr;
    NeuronCompilation* compilation = nullptr;
    NeuronExecution* execution = nullptr;
    try {
        check(a.modelCreate(&model), "NeuronModel_create");
        check(a.modelOperand(model, &inputType), "add input");
        check(a.modelOperand(model, &filterType), "add filter");
        check(a.modelOperand(model, &biasType), "add bias");
        for (int i = 0; i < 7; i++) check(a.modelOperand(model, &scalarType), "add conv int32");
        check(a.modelOperand(model, &outputType), "add output");
        check(a.modelValue(model, 1, filter.data(), filter.size() * sizeof(_Float16)), "set weights");
        check(a.modelValue(model, 2, bias.data(), bias.size() * sizeof(_Float16)), "set bias");
        const int32_t scalars[7] = {int32_t(p.pad), int32_t(p.pad), int32_t(p.pad), int32_t(p.pad), 1, 1, 0};
        for (int i = 0; i < 7; i++) check(a.modelValue(model, 3 + i, &scalars[i], sizeof(int32_t)), "set conv arg");
        const uint32_t opInputs[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        const uint32_t opOutput[1] = {10}, externalInput[1] = {0};
        check(a.modelOperation(model, OP_CONV_2D, 10, opInputs, 1, opOutput), "CONV_2D");
        check(a.modelIO(model, 1, externalInput, 1, opOutput), "NeuronModel_identifyInputsAndOutputs");
        check(a.modelFinish(model), "NeuronModel_finish");
        const NeuronDevice* devices[1] = {device};
        bool supported = false;
        check(a.modelSupported(model, devices, 1, &supported), "NeuronModel_getSupportedOperationsForDevices");
        std::printf("NPU_SUPPORT profile=%s device=%s supported=%s input=%ux%ux%u kernel=%ux%u output=%ux%ux%u\n",
                    p.name, target.c_str(), supported ? "yes" : "no", p.h, p.w, p.inputChannels,
                    p.kernel, p.kernel, oh, ow, p.outputChannels);
        std::fflush(stdout);
        if (!supported) {
            a.modelFree(model);
            return false;
        }
        const auto compileStart = std::chrono::steady_clock::now();
        check(a.compilationCreate(model, devices, 1, &compilation), "NeuronCompilation_createForDevices");
        check(a.compilationFinish(compilation), "NeuronCompilation_finish");
        const double compileMs = std::chrono::duration<double, std::milli>(
                std::chrono::steady_clock::now() - compileStart).count();
        check(a.executionCreate(compilation, &execution), "NeuronExecution_create");
        check(a.executionSetInput(execution, 0, nullptr, input.data(), input.size() * sizeof(_Float16)), "set input");
        check(a.executionSetOutput(execution, 0, nullptr, output.data(), output.size() * sizeof(_Float16)), "set output");
        std::vector<double> times;
        times.reserve(runs);
        for (int i = 0; i < warmup + runs; i++) {
            auto start = std::chrono::steady_clock::now();
            check(a.executionCompute(execution), "NeuronExecution_compute");
            if (i >= warmup) times.push_back(std::chrono::duration<double, std::milli>(
                    std::chrono::steady_clock::now() - start).count());
        }
        // Analytic golden result: input=ones, weights=1/(Cin*K*K), bias=0.
        // Border convolution samples some implicit zeros; count valid kernel rows/cols.
        size_t bad = 0;
        double maxError = 0.0;
        for (uint32_t y = 0; y < oh; y++) {
            uint32_t rows = 0;
            for (uint32_t ky = 0; ky < p.kernel; ky++) {
                const int yy = int(y) + int(ky) - int(p.pad);
                if (yy >= 0 && yy < int(p.h)) rows++;
            }
            for (uint32_t x = 0; x < ow; x++) {
                uint32_t cols = 0;
                for (uint32_t kx = 0; kx < p.kernel; kx++) {
                    const int xx = int(x) + int(kx) - int(p.pad);
                    if (xx >= 0 && xx < int(p.w)) cols++;
                }
                const double expected = double(rows) * cols * p.inputChannels * float(kernelWeight);
                for (uint32_t channel = 0; channel < p.outputChannels; channel++) {
                    const float actual = float(output[(y * ow + x) * p.outputChannels + channel]);
                    const double err = std::fabs(double(actual) - expected);
                    if (!std::isfinite(actual) || err > 0.03) bad++;
                    maxError = std::max(maxError, err);
                }
            }
        }
        std::sort(times.begin(), times.end());
        const double meanMs = std::accumulate(times.begin(), times.end(), 0.0) / times.size();
        const double macs = double(oh) * ow * p.outputChannels * p.inputChannels * p.kernel * p.kernel;
        std::printf("NPU_VERIFY profile=%s wrong=%zu/%zu max_abs_error=%.6f\n",
                    p.name, bad, output.size(), maxError);
        if (bad) throw std::runtime_error(std::string("Numerical verification failed for ") + p.name);
        std::printf("NPU_BENCH_PASS profile=%s device=%s dtype=fp16 mean_ms=%.3f p50_ms=%.3f p95_ms=%.3f calls_per_sec=%.2f gmac_per_sec=%.2f macs=%.0f compile_ms=%.3f runs=%d\n",
                    p.name, target.c_str(), meanMs, percentile(times, 0.5), percentile(times, 0.95),
                    1000.0 / meanMs, macs / (meanMs * 1e6), macs, compileMs, runs);
        a.executionFree(execution);
        a.compilationFree(compilation);
        a.modelFree(model);
        return true;
    } catch (...) {
        if (execution) a.executionFree(execution);
        if (compilation) a.compilationFree(compilation);
        if (model) a.modelFree(model);
        throw;
    }
}

int main(int argc, char** argv) {
    try {
        if (argc < 2 || argc > 5) {
            std::fprintf(stderr, "Usage: %s tiny|stem|residual|all [mtk-mdla] [warmup=100] [runs=1000]\n", argv[0]);
            return 2;
        }
        std::string which(argv[1]), deviceName = argc > 2 ? argv[2] : "mtk-mdla";
        int warmup = argc > 3 ? std::stoi(argv[3]) : 100;
        int runs = argc > 4 ? std::stoi(argv[4]) : 1000;
        if ((which != "tiny" && which != "stem" && which != "residual" && which != "all") ||
            (deviceName != "mtk-mdla" && deviceName != "mtk-dsp") || warmup < 0 ||
            runs < 1 || runs > 200000) throw std::runtime_error("Invalid arguments");
        void* lib = nullptr;
        for (const char* path : {"libneuronusdk_adapter.9.mtk.so", "libneuronusdk_adapter.mtk.so",
                                 "/system_ext/lib64/libneuronusdk_adapter.9.mtk.so"}) {
            lib = dlopen(path, RTLD_NOW | RTLD_LOCAL);
            if (lib) { std::printf("NPU_ADAPTER=%s\n", path); break; }
        }
        if (!lib) throw std::runtime_error("MediaTek Neuron Adapter not found; this is an MTK-specific benchmark");
        int succeeded = 0, attempted = 0;
        try {
            NeuronApi api(lib);
            NeuronDevice* selected = api.select(deviceName);
            for (const Profile& p : PROFILES) {
                bool match = (which == "all") ||
                    (which == "tiny" && std::strcmp(p.name, "tiny_conv") == 0) ||
                    (which == "stem" && std::strcmp(p.name, "katago_stem") == 0) ||
                    (which == "residual" && std::strcmp(p.name, "katago_resconv") == 0);
                if (!match) continue;
                attempted++;
                if (runProfile(api, selected, deviceName, p, warmup, runs)) succeeded++;
            }
            std::printf("NPU_BENCH_SUMMARY device=%s success=%d attempted=%d warmup=%d runs=%d\n",
                        deviceName.c_str(), succeeded, attempted, warmup, runs);
        } catch (...) {
            dlclose(lib);
            throw;
        }
        dlclose(lib);
        return succeeded == attempted ? 0 : 1;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "NPU_BENCH_FAIL: %s\n", e.what());
        return 1;
    }
}
